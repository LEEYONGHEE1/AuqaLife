package com.project.aqualife.fragment

interface OnBackPressedListener {
    fun onBackPressed()
}