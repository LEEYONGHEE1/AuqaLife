package com.project.aqualife.data

data class TemperatureRegulatorSchedule(val aquariumName : String, val start : String, val end : String, val name : String, val state : String, val type : String)