# Aqualife
## 창업 동아리 프로젝트
- 개발환경
  - Firebase(Auth, RealtimeDatabase)

## LOG
- 2022.09.18 기본 Activity, Fragment 틀 제작
- 2022.10.06 Fragment 화면 일부 추가
- 2022-10.10 Home, Regulator, Temperature 화면 기능 구현(Firebase 사용)
